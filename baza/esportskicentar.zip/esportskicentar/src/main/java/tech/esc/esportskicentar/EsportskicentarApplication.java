package tech.esc.esportskicentar;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EsportskicentarApplication {

	public static void main(String[] args) {
		SpringApplication.run(EsportskicentarApplication.class, args);
	}

}
